import * as React from "react";
import { cn } from "@/lib/utils";
import { Plus, GripVertical } from "lucide-react";

export type Task = {
  id: string;
  title: string;
  description?: string;
  tags?: string[];
  assignees?: { name: string }[];
  priority?: "low" | "medium" | "high";
};

export default function KanbanBoard() {
  const [columns, setColumns] = React.useState<Record<string, Task[]>>({
    backlog: [
      {
        id: "t1",
        title: "Collect requirements",
        tags: ["discovery"],
        assignees: [{ name: "RS" }],
        priority: "low",
      },
      {
        id: "t2",
        title: "Define color system",
        tags: ["design"],
        assignees: [{ name: "AD" }],
        priority: "medium",
      },
    ],
    progress: [
      {
        id: "t3",
        title: "Build sidebar navigation",
        tags: ["frontend"],
        assignees: [{ name: "KM" }],
        priority: "high",
      },
      {
        id: "t4",
        title: "Implement DnD",
        tags: ["feature"],
        assignees: [{ name: "RS" }],
        priority: "medium",
      },
    ],
    review: [
      {
        id: "t5",
        title: "Write unit tests",
        tags: ["testing"],
        assignees: [{ name: "JL" }],
        priority: "low",
      },
    ],
    done: [
      {
        id: "t6",
        title: "Project setup",
        tags: ["chore"],
        assignees: [{ name: "RS" }],
        priority: "low",
      },
    ],
  });

  const dragTask = React.useRef<{ id: string; from: string } | null>(null);

  const onDragStart = (taskId: string, from: string) => (e: React.DragEvent) => {
    dragTask.current = { id: taskId, from };
    e.dataTransfer.setData("text/plain", JSON.stringify({ id: taskId, from }));
    e.dataTransfer.effectAllowed = "move";
  };

  const onDrop = (to: string) => (e: React.DragEvent) => {
    e.preventDefault();
    const data = dragTask.current ?? JSON.parse(e.dataTransfer.getData("text/plain"));
    if (!data) return;
    if (data.from === to) return;
    setColumns((prev) => {
      const fromTasks = [...prev[data.from]];
      const toTasks = [...prev[to]];
      const idx = fromTasks.findIndex((t) => t.id === data.id);
      if (idx === -1) return prev;
      const [task] = fromTasks.splice(idx, 1);
      toTasks.unshift(task);
      return { ...prev, [data.from]: fromTasks, [to]: toTasks };
    });
    dragTask.current = null;
  };

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
      <KanbanColumn
        title="Backlog"
        accent="from-slate-200 to-slate-100"
        onDrop={onDrop("backlog")}
      >
        {columns.backlog.map((t) => (
          <KanbanCard key={t.id} task={t} onDragStart={onDragStart(t.id, "backlog")} />
        ))}
      </KanbanColumn>
      <KanbanColumn
        title="In Progress"
        accent="from-primary/15 to-violet-500/10"
        onDrop={onDrop("progress")}
      >
        {columns.progress.map((t) => (
          <KanbanCard key={t.id} task={t} onDragStart={onDragStart(t.id, "progress")} />
        ))}
      </KanbanColumn>
      <KanbanColumn
        title="Review"
        accent="from-amber-200/40 to-amber-100/30"
        onDrop={onDrop("review")}
      >
        {columns.review.map((t) => (
          <KanbanCard key={t.id} task={t} onDragStart={onDragStart(t.id, "review")} />
        ))}
      </KanbanColumn>
      <KanbanColumn
        title="Done"
        accent="from-emerald-200/40 to-emerald-100/30"
        onDrop={onDrop("done")}
      >
        {columns.done.map((t) => (
          <KanbanCard key={t.id} task={t} onDragStart={onDragStart(t.id, "done")} />
        ))}
      </KanbanColumn>
    </div>
  );
}

function KanbanColumn({
  title,
  children,
  accent,
  onDrop,
}: {
  title: string;
  accent: string;
  children: React.ReactNode;
  onDrop: (e: React.DragEvent) => void;
}) {
  return (
    <div
      className={cn(
        "group rounded-xl border bg-card p-3 shadow-sm",
        "bg-gradient-to-b", // accent gradient frame
        accent,
      )}
      onDragOver={(e) => e.preventDefault()}
      onDrop={onDrop}
      aria-label={`${title} column`}
    >
      <div className="mb-3 flex items-center justify-between rounded-md bg-card/80 p-2">
        <div className="text-sm font-semibold">{title}</div>
        <button className="rounded-md p-1 text-muted-foreground hover:bg-accent hover:text-accent-foreground" aria-label={`Add task to ${title}`}>
          <Plus className="size-4" />
        </button>
      </div>
      <div className="space-y-3">
        {children}
      </div>
    </div>
  );
}

function KanbanCard({ task, onDragStart }: { task: Task; onDragStart: (e: React.DragEvent) => void }) {
  return (
    <article
      className="cursor-grab rounded-lg border bg-background p-3 shadow-sm transition-shadow hover:shadow-md"
      draggable
      onDragStart={onDragStart}
      aria-grabbed={false}
    >
      <div className="flex items-start gap-2">
        <GripVertical className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
        <div className="min-w-0 flex-1">
          <h4 className="truncate text-sm font-medium leading-tight">{task.title}</h4>
          {task.description ? (
            <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{task.description}</p>
          ) : null}
        </div>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        {task.tags?.map((t) => (
          <span key={t} className="rounded-full bg-accent px-2 py-0.5 text-[10px] font-medium text-accent-foreground">
            {t}
          </span>
        ))}
        {task.priority ? (
          <span
            className={cn(
              "ml-auto rounded-full px-2 py-0.5 text-[10px] font-semibold",
              task.priority === "high" && "bg-red-500/15 text-red-600 dark:text-red-400",
              task.priority === "medium" && "bg-amber-500/15 text-amber-600 dark:text-amber-400",
              task.priority === "low" && "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400",
            )}
          >
            {task.priority}
          </span>
        ) : null}
      </div>
      {task.assignees && task.assignees.length > 0 ? (
        <div className="mt-3 flex -space-x-2">
          {task.assignees.map((a) => (
            <div
              key={a.name}
              title={a.name}
              className="flex size-6 items-center justify-center rounded-full border bg-gradient-to-br from-primary to-violet-500 text-[10px] font-bold text-primary-foreground"
            >
              {a.name}
            </div>
          ))}
        </div>
      ) : null}
    </article>
  );
}
