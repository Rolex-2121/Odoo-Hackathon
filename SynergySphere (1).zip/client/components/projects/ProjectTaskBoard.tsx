import * as React from "react";
import { cn } from "@/lib/utils";
import { GripVertical, CalendarDays } from "lucide-react";

export type Task = {
  id: string;
  title: string;
  due: string; // ISO
  assignee: { name: string; initials: string };
};

type ColumnKey = "todo" | "inprogress" | "done";

import { useEffect, useState } from "react";
import { fetchProject, currentUserId } from "@/lib/api";

export default function ProjectTaskBoard({ projectId }: { projectId: string }) {
  const [project, setProject] = useState<{ id: string; name: string; memberIds: string[]; leaderIds: string[] } | null>(null);
  useEffect(() => {
    fetchProject(projectId).then(setProject).catch(() => setProject(null));
  }, [projectId]);

  const [columns, setColumns] = React.useState<Record<ColumnKey, Task[]>>({
    todo: [
      { id: "1", title: "Set up repo & CI", due: "2025-09-12", assignee: { name: "Riya Somani", initials: "RS" } },
      { id: "2", title: "Create information architecture", due: "2025-09-15", assignee: { name: "Alex Doe", initials: "AD" } },
    ],
    inprogress: [
      { id: "3", title: "Build auth flow", due: "2025-09-10", assignee: { name: "Kim Ma", initials: "KM" } },
    ],
    done: [
      { id: "4", title: "Define color palette", due: "2025-09-05", assignee: { name: "John Lee", initials: "JL" } },
    ],
  });

  const dragTask = React.useRef<{ id: string; from: ColumnKey } | null>(null);

  const onDragStart = (taskId: string, from: ColumnKey) => (e: React.DragEvent) => {
    dragTask.current = { id: taskId, from };
    e.dataTransfer.setData("text/plain", JSON.stringify({ id: taskId, from }));
    e.dataTransfer.effectAllowed = "move";
  };

  const onDrop = (to: ColumnKey) => (e: React.DragEvent) => {
    e.preventDefault();
    const data = dragTask.current ?? JSON.parse(e.dataTransfer.getData("text/plain"));
    if (!data) return;
    if (data.from === to) return;
    setColumns((prev) => {
      const fromTasks = [...prev[data.from]];
      const toTasks = [...prev[to]];
      const idx = fromTasks.findIndex((t) => t.id === data.id);
      if (idx === -1) return prev;
      const [task] = fromTasks.splice(idx, 1);
      toTasks.unshift(task);
      return { ...prev, [data.from]: fromTasks, [to]: toTasks } as typeof prev;
    });
    dragTask.current = null;
  };

  const isLeader = project ? project.leaderIds.includes(currentUserId) : false;
  const memberOptions = project?.memberIds.map((id) => ({ id, label: id })) || [];
  const assign = (taskId: string, userId: string) => {
    if (!userId) return;
    setColumns((prev) => {
      const update = (arr: Task[]) => arr.map((t) => (t.id === taskId ? { ...t, assignee: { name: userId, initials: userId.slice(0, 2).toUpperCase() } } : t));
      return { todo: update(prev.todo), inprogress: update(prev.inprogress), done: update(prev.done) } as typeof prev;
    });
  };

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
      <BoardColumn title="To-Do" accent="from-brand-blue/15 to-brand-blue/5" onDrop={onDrop("todo")}>
        {columns.todo.map((t) => (
          <TaskCard key={t.id} task={t} onDragStart={onDragStart(t.id, "todo")} allowAssign={isLeader} members={memberOptions} onAssign={assign} />
        ))}
      </BoardColumn>
      <BoardColumn title="In Progress" accent="from-brand-purple/15 to-brand-purple/5" onDrop={onDrop("inprogress")}>
        {columns.inprogress.map((t) => (
          <TaskCard key={t.id} task={t} onDragStart={onDragStart(t.id, "inprogress")} allowAssign={isLeader} members={memberOptions} onAssign={assign} />
        ))}
      </BoardColumn>
      <BoardColumn title="Done" accent="from-brand-teal/15 to-brand-teal/5" onDrop={onDrop("done")}>
        {columns.done.map((t) => (
          <TaskCard key={t.id} task={t} onDragStart={onDragStart(t.id, "done")} allowAssign={isLeader} members={memberOptions} onAssign={assign} />
        ))}
      </BoardColumn>
    </div>
  );
}

function BoardColumn({ title, children, accent, onDrop }: { title: string; children: React.ReactNode; accent: string; onDrop: (e: React.DragEvent) => void }) {
  return (
    <div className={cn("rounded-xl border bg-card p-3 shadow-sm bg-gradient-to-b", accent)} onDragOver={(e) => e.preventDefault()} onDrop={onDrop}>
      <div className="mb-3 rounded-md bg-card/80 p-2 text-sm font-semibold">{title}</div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function TaskCard({ task, onDragStart, allowAssign, members, onAssign }: { task: Task; onDragStart: (e: React.DragEvent) => void; allowAssign?: boolean; members?: { id: string; label: string }[]; onAssign?: (taskId: string, userId: string) => void }) {
  return (
    <article className="cursor-grab rounded-lg border bg-background p-3 shadow-sm transition-shadow hover:shadow-md" draggable onDragStart={onDragStart}>
      <div className="flex items-start gap-2">
        <GripVertical className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
        <div className="min-w-0 flex-1">
          <h4 className="truncate text-sm font-medium leading-tight">{task.title}</h4>
          <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
            <div className="flex size-6 items-center justify-center rounded-full border bg-gradient-to-br from-brand-blue via-brand-purple to-brand-teal text-[10px] font-bold text-white">{task.assignee.initials}</div>
            <span className="inline-flex items-center gap-1"><CalendarDays className="size-3" /> {new Date(task.due).toLocaleDateString()}</span>
          </div>
          {allowAssign && members && onAssign ? (
            <div className="mt-2">
              <select className="w-full rounded-md border bg-background px-2 py-1 text-xs" onChange={(e) => onAssign(task.id, e.target.value)} defaultValue="">
                <option value="">Assign to…</option>
                {members.map((m) => (
                  <option key={m.id} value={m.id}>{m.label}</option>
                ))}
              </select>
            </div>
          ) : null}
        </div>
      </div>
    </article>
  );
}
