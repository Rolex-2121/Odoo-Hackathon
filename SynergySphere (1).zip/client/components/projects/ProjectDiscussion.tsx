import * as React from "react";
import { Smile, CornerDownRight } from "lucide-react";
import { cn } from "@/lib/utils";

type Reaction = { emoji: string; count: number; reacted: boolean };

type Message = {
  id: string;
  author: string;
  initials: string;
  text: string;
  time: string;
  reactions: Reaction[];
  replies?: Message[];
};

const initial: Message[] = [
  {
    id: "m1",
    author: "Riya Somani",
    initials: "RS",
    text: "Let's finalize the sprint scope and make sure the Kanban reflects priorities.",
    time: "10:02 AM",
    reactions: [
      { emoji: "👍", count: 3, reacted: false },
      { emoji: "🎯", count: 1, reacted: false },
    ],
    replies: [
      {
        id: "m1r1",
        author: "Alex Doe",
        initials: "AD",
        text: "Agreed. I can own the auth tasks.",
        time: "10:05 AM",
        reactions: [{ emoji: "✅", count: 2, reacted: false }],
      },
    ],
  },
  {
    id: "m2",
    author: "Kim Ma",
    initials: "KM",
    text: "Design tokens for blue/purple/teal are live.",
    time: "11:40 AM",
    reactions: [{ emoji: "💜", count: 4, reacted: false }],
  },
];

export default function ProjectDiscussion() {
  const [messages, setMessages] = React.useState<Message[]>(initial);
  const [input, setInput] = React.useState("");

  const toggleReaction = (id: string, emoji: string) => {
    setMessages((prev) =>
      prev.map((m) =>
        m.id === id
          ? {
              ...m,
              reactions: m.reactions.map((r) =>
                r.emoji === emoji
                  ? { ...r, reacted: !r.reacted, count: r.reacted ? r.count - 1 : r.count + 1 }
                  : r,
              ),
            }
          : {
              ...m,
              replies: m.replies?.map((r) =>
                r.id === id
                  ? {
                      ...r,
                      reactions: r.reactions.map((rx) =>
                        rx.emoji === emoji
                          ? { ...rx, reacted: !rx.reacted, count: rx.reacted ? rx.count - 1 : rx.count + 1 }
                          : rx,
                      ),
                    }
                  : r,
              ),
            },
      ),
    );
  };

  const addMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    const msg: Message = {
      id: Math.random().toString(36).slice(2),
      author: "You",
      initials: "YY",
      text: input.trim(),
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      reactions: [],
    };
    setMessages((p) => [...p, msg]);
    setInput("");
  };

  return (
    <div className="rounded-xl border bg-card p-4 shadow-sm">
      <div className="space-y-4">
        {messages.map((m) => (
          <MessageBubble key={m.id} message={m} onReact={toggleReaction} />
        ))}
      </div>

      <form onSubmit={addMessage} className="mt-4 flex items-center gap-2">
        <div className="flex size-9 items-center justify-center rounded-full border bg-gradient-to-br from-brand-blue via-brand-purple to-brand-teal text-white">YY</div>
        <input
          className="flex-1 rounded-md border bg-background px-3 py-2 text-sm outline-none ring-offset-background focus-visible:ring-2 focus-visible:ring-ring"
          placeholder="Write a message..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button type="submit" className="rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90">
          Send
        </button>
      </form>
    </div>
  );
}

function MessageBubble({ message, onReact, depth = 0 }: { message: Message; onReact: (id: string, emoji: string) => void; depth?: number }) {
  return (
    <div className={cn("flex gap-3", depth > 0 && "ml-10")}> 
      <div className="flex size-9 shrink-0 items-center justify-center rounded-full border bg-gradient-to-br from-brand-blue via-brand-purple to-brand-teal text-white">{message.initials}</div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="font-medium text-foreground">{message.author}</span>
          <span>{message.time}</span>
        </div>
        <div className="mt-1 rounded-lg border bg-background p-3 text-sm shadow-sm">{message.text}</div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          {message.reactions.map((r) => (
            <button
              key={r.emoji}
              className={cn(
                "rounded-full border px-2 py-0.5 text-xs",
                r.reacted ? "bg-accent text-foreground" : "text-muted-foreground",
              )}
              onClick={() => onReact(message.id, r.emoji)}
              type="button"
            >
              {r.emoji} {r.count}
            </button>
          ))}
          <button className="ml-1 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground" type="button">
            <Smile className="size-3" /> React
          </button>
          <div className="ml-auto inline-flex items-center gap-1 text-xs text-muted-foreground">
            <CornerDownRight className="size-3" /> Reply
          </div>
        </div>
        {message.replies?.map((r) => (
          <div key={r.id} className="mt-3">
            <MessageBubble message={r} onReact={onReact} depth={depth + 1} />
          </div>
        ))}
      </div>
    </div>
  );
}
