import { NavLink, Outlet } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  LayoutGrid,
  KanbanSquare,
  Home,
  Calendar,
  Settings,
  Search,
  SunMedium,
  Moon,
  Menu,
} from "lucide-react";
import * as React from "react";

export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = React.useState(false);
  const [dark, setDark] = React.useState(
    typeof document !== "undefined" && document.documentElement.classList.contains("dark"),
  );

  const toggleTheme = React.useCallback(() => {
    const el = document.documentElement;
    el.classList.toggle("dark");
    setDark(el.classList.contains("dark"));
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-72 border-r bg-card/80 backdrop-blur supports-[backdrop-filter]:bg-card/60 transition-transform duration-300",
          sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
        )}
      >
        <div className="flex h-16 items-center gap-2 border-b px-4">
          <div className="flex size-9 items-center justify-center rounded-md bg-gradient-to-br from-primary to-violet-500 text-primary-foreground shadow-sm">
            <LayoutGrid className="size-5" />
          </div>
          <div className="leading-tight">
            <div className="text-sm font-semibold tracking-tight">SynergySphere</div>
            <div className="text-xs text-muted-foreground">Team Collaboration</div>
          </div>
        </div>
        <nav className="p-3">
          <SidebarItem icon={Home} label="Projects" to="/" />
          <SidebarItem icon={KanbanSquare} label="Tasks" to="/tasks" />
          <SidebarItem icon={Calendar} label="Discussions" to="/discussions" />
          <SidebarItem icon={Settings} label="Profile" to="/profile" />
          <div className="mt-6 rounded-lg bg-gradient-to-br from-brand-blue/10 via-brand-purple/10 to-brand-teal/10 p-4 text-sm">
            <p className="font-medium">SynergySphere</p>
            <p className="mt-1 text-muted-foreground">
              Collaborate with tasks, boards, and discussions.
            </p>
          </div>
        </nav>
      </aside>

      <div className="md:pl-72">
        <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex h-16 items-center gap-3 px-4">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setSidebarOpen((v) => !v)}
              aria-label="Toggle sidebar"
            >
              <Menu className="size-5" />
            </Button>
            <div className="relative ml-auto w-full max-w-lg">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <input
                className="w-full rounded-md border bg-background pl-10 pr-10 py-2 text-sm shadow-sm outline-none ring-offset-background placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring"
                placeholder="Search tasks, assignees, tags..."
              />
            </div>
            <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="Toggle theme">
              {dark ? <SunMedium className="size-5" /> : <Moon className="size-5" />}
            </Button>
          </div>
        </header>

        <main className="container py-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function SidebarItem({
  icon: Icon,
  label,
  to,
  disabled,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  to?: string;
  disabled?: boolean;
}) {
  const content = (
    <div
      className={cn(
        "group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
        disabled
          ? "cursor-not-allowed text-muted-foreground/70"
          : "hover:bg-accent hover:text-accent-foreground",
      )}
    >
      <Icon className="size-4" />
      <span>{label}</span>
    </div>
  );

  if (disabled || !to) return content;
  return (
    <NavLink to={to} className={({ isActive }) => cn(isActive && "bg-accent text-accent-foreground rounded-md") }>
      {content}
    </NavLink>
  );
}
