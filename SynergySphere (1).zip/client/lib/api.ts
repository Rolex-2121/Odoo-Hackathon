import type { CreateProjectRequest, CreateProjectResponse, Project, User } from "@shared/api";

export const currentUserId = "yash"; // demo current user

export async function fetchUsers(): Promise<User[]> {
  const res = await fetch("/api/team/users");
  if (!res.ok) throw new Error("Failed to load users");
  return res.json();
}

export async function fetchProject(id: string): Promise<Project> {
  const res = await fetch(`/api/projects/${id}`);
  if (!res.ok) throw new Error("Project not found");
  return res.json();
}

export async function createProject(input: CreateProjectRequest): Promise<CreateProjectResponse> {
  const res = await fetch("/api/projects", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-user-id": currentUserId },
    body: JSON.stringify(input),
  });
  if (!res.ok) throw new Error("Failed to create project");
  return res.json();
}
