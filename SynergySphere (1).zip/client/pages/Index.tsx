import KanbanBoard from "@/components/kanban/KanbanBoard";

export default function Index() {
  return (
    <div className="space-y-8">
      <header>
        <h1 className="font-display bg-gradient-to-r from-brand-blue via-brand-purple to-brand-teal bg-clip-text text-3xl font-extrabold tracking-tight text-transparent md:text-4xl">
          SynergySphere Dashboard
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Keep projects on track with progress, task boards, and team discussions.
        </p>
      </header>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        <ProjectCard id="alpha" name="Website Revamp" tasksDone={5} tasksTotal={10} gradient="from-brand-blue via-brand-purple to-brand-teal" />
        <ProjectCard id="beta" name="Mobile App" tasksDone={12} tasksTotal={20} gradient="from-brand-purple via-brand-teal to-brand-blue" />
        <ProjectCard id="gamma" name="Marketing Launch" tasksDone={7} tasksTotal={9} gradient="from-brand-teal via-brand-blue to-brand-purple" />
      </section>

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold tracking-tight">Kanban Board</h2>
          <div className="flex items-center gap-3">
            <a href="/new-project" className="rounded-md bg-primary px-3 py-2 text-xs font-medium text-primary-foreground hover:bg-primary/90">New Project</a>
            <span className="text-xs text-muted-foreground">Drag tasks between columns</span>
          </div>
        </div>
        <KanbanBoard />
      </section>
    </div>
  );
}

import { Link } from "react-router-dom";
import { Progress } from "@/components/ui/progress";

function ProjectCard({ id, name, tasksDone, tasksTotal, gradient }: { id: string; name: string; tasksDone: number; tasksTotal: number; gradient: string }) {
  const percent = Math.round((tasksDone / tasksTotal) * 100);
  return (
    <div className="group rounded-xl border bg-card p-5 shadow-sm">
      <div className={`rounded-md p-0.5 bg-gradient-to-r ${gradient}`}>
        <div className="rounded-[6px] bg-card px-3 py-2">
          <div className="text-sm font-medium">{name}</div>
          <div className="mt-2 text-xs text-muted-foreground">{tasksDone}/{tasksTotal} tasks complete</div>
        </div>
      </div>
      <div className="mt-4">
        <Progress value={percent} />
        <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
          <span>{percent}%</span>
          <Link to={`/project/${id}`} className="font-medium text-primary underline-offset-4 hover:underline">View project</Link>
        </div>
      </div>
    </div>
  );
}
