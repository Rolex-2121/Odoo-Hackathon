import { useParams } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProjectTaskBoard from "@/components/projects/ProjectTaskBoard";
import ProjectDiscussion from "@/components/projects/ProjectDiscussion";

export default function Project() {
  const { id } = useParams();
  const title = {
    alpha: "Website Revamp",
    beta: "Mobile App",
    gamma: "Marketing Launch",
  }[id as keyof any] || "Project";

  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">{title}</h1>
        <p className="text-sm text-muted-foreground">Plan tasks and collaborate in discussions.</p>
      </div>

      <Tabs defaultValue="board" className="w-full">
        <TabsList>
          <TabsTrigger value="board">Task Board</TabsTrigger>
          <TabsTrigger value="discussion">Discussion</TabsTrigger>
        </TabsList>
        <TabsContent value="board">
          <ProjectTaskBoard projectId={id!} />
        </TabsContent>
        <TabsContent value="discussion">
          <ProjectDiscussion />
        </TabsContent>
      </Tabs>
    </div>
  );
}
