import * as React from "react";
import { useNavigate } from "react-router-dom";
import { createProject, fetchUsers, currentUserId } from "@/lib/api";

export default function NewProject() {
  const nav = useNavigate();
  const [name, setName] = React.useState("");
  const [users, setUsers] = React.useState<{ id: string; name: string }[]>([]);
  const [selected, setSelected] = React.useState<string>("");
  const [extraIds, setExtraIds] = React.useState<string>("");
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    fetchUsers().then((u) => setUsers(u));
  }, []);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const typed = extraIds
        .split(/[,\s]+/)
        .map((s) => s.trim())
        .filter(Boolean);
      const members = Array.from(new Set([selected || undefined, ...typed].filter(Boolean))) as string[];
      const res = await createProject({ name, memberIds: members });
      nav(`/project/${res.id}`);
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight">Create a new project</h1>
        <p className="text-sm text-muted-foreground">You (user_id: {currentUserId}) will be a Leader. Anyone you add by user_id will also get Leader rights for this project.</p>
      </div>
      <form onSubmit={onSubmit} className="space-y-4 rounded-xl border bg-card p-6 shadow-sm">
        <div>
          <label className="text-sm font-medium">Project name</label>
          <input className="mt-1 w-full rounded-md border bg-background px-3 py-2 text-sm" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g., Documentation Sprint" required />
        </div>
        <div>
          <label className="text-sm font-medium">Add a teammate (optional)</label>
          <select className="mt-1 w-full rounded-md border bg-background px-3 py-2 text-sm" value={selected} onChange={(e) => setSelected(e.target.value)}>
            <option value="">— Select by user_id —</option>
            {users.filter((u) => u.id !== currentUserId).map((u) => (
              <option key={u.id} value={u.id}>
                {u.name} ({u.id})
              </option>
            ))}
          </select>
          <p className="mt-1 text-xs text-muted-foreground">Or paste additional user_ids separated by commas/spaces.</p>
          <input className="mt-1 w-full rounded-md border bg-background px-3 py-2 text-sm" value={extraIds} onChange={(e) => setExtraIds(e.target.value)} placeholder="e.g., riya alex" />
        </div>
        {error ? <div className="text-sm text-red-600">{error}</div> : null}
        <button type="submit" disabled={loading} className="w-full rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
          {loading ? "Creating..." : "Create project"}
        </button>
      </form>
      <div className="rounded-lg border bg-card p-4 text-sm">
        <div className="font-medium">Demo users</div>
        <ul className="mt-2 grid grid-cols-2 gap-2">
          {users.map((u) => (
            <li key={u.id} className="rounded-md border px-3 py-2">
              <div className="text-sm font-medium">{u.name}</div>
              <div className="text-xs text-muted-foreground">user_id: {u.id}</div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
