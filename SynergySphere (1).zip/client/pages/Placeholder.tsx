export default function Placeholder({ title }: { title: string }) {
  return (
    <div className="mx-auto max-w-xl rounded-xl border bg-card p-8 text-center shadow-sm">
      <h1 className="font-display text-2xl font-bold">{title}</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        This is a placeholder view. Tell me what you want here and I can generate it.
      </p>
    </div>
  );
}
