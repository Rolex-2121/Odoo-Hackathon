/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

// SynergySphere shared types
export type UserID = string;
export type ProjectID = string;

export interface User {
  id: UserID;
  name: string;
  initials: string;
}

export interface Project {
  id: ProjectID;
  name: string;
  memberIds: UserID[];
  leaderIds: UserID[]; // users with leader rights for this project
}

export interface CreateProjectRequest {
  name: string;
  memberIds: UserID[]; // users to add as co-leaders as well
}

export interface CreateProjectResponse extends Project {}
