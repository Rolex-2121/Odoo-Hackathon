import type { RequestHandler } from "express";
import type { CreateProjectRequest, CreateProjectResponse, Project, User } from "@shared/api";
import crypto from "crypto";

// In-memory demo data
const users: User[] = [
  { id: "yash", name: "Yash Shinde", initials: "YS" },
  { id: "riya", name: "Riya Somani", initials: "RS" },
  { id: "alex", name: "Alex Doe", initials: "AD" },
  { id: "kim", name: "Kim Ma", initials: "KM" },
  { id: "john", name: "John Lee", initials: "JL" },
];

const projects: Project[] = [
  { id: "alpha", name: "Website Revamp", memberIds: users.map((u) => u.id), leaderIds: ["riya"] },
  { id: "beta", name: "Mobile App", memberIds: users.map((u) => u.id), leaderIds: ["riya"] },
  { id: "gamma", name: "Marketing Launch", memberIds: users.map((u) => u.id), leaderIds: ["riya"] },
];

export const listUsers: RequestHandler = (_req, res) => {
  res.json(users);
};

export const listProjects: RequestHandler = (_req, res) => {
  res.json(projects);
};

export const getProject: RequestHandler = (req, res) => {
  const id = String(req.params.id);
  const p = projects.find((x) => x.id === id);
  if (!p) return res.status(404).json({ message: "Project not found" });
  res.json(p);
};

export const createProject: RequestHandler = (req, res) => {
  const userId = String(req.header("x-user-id") || "");
  const body = req.body as CreateProjectRequest;
  if (!userId) return res.status(400).json({ message: "Missing x-user-id header" });
  if (!body?.name) return res.status(400).json({ message: "Missing name" });
  const id = crypto.randomUUID().slice(0, 8);
  const memberIds = Array.from(new Set([userId, ...(body.memberIds || [])]));
  const leaderIds = Array.from(new Set([userId, ...(body.memberIds || [])])); // creator + invited are leaders
  const project: Project = { id, name: body.name, memberIds, leaderIds };
  projects.push(project);
  const response: CreateProjectResponse = project;
  res.status(201).json(response);
};
